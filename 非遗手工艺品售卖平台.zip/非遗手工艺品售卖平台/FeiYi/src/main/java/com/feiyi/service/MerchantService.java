package com.feiyi.service;

import com.feiyi.pojo.Merchant;
import com.feiyi.pojo.Goods;
import com.github.pagehelper.PageInfo;
import java.util.List;

public interface MerchantService {
    
    // 根据ID查询商家
    Merchant getMerchantById(Integer id);
    
    // 根据用户名查询商家
    Merchant getMerchantByUsername(String username);
    
    // 分页查询所有商家
    PageInfo<Merchant> getAllMerchantsByPage(Integer pageNum, Integer pageSize);
    
    // 添加商家
    boolean addMerchant(Merchant merchant);
    
    // 更新商家信息
    boolean updateMerchant(Merchant merchant);
    
    // 删除商家
    boolean deleteMerchant(Integer id);
    
    // 审核商家
    boolean approveMerchant(Integer id);
    
    // 冻结商家
    boolean freezeMerchant(Integer id);
    
    // 查询某个商家的所有商品
    PageInfo<Goods> getGoodsByMerchantId(Integer merchantId, Integer pageNum, Integer pageSize);
    
    // 统计某个商家的商品数量
    int countGoodsByMerchantId(Integer merchantId);
}
