package com.feiyi.mapper;

import com.feiyi.pojo.User;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface UserMapper {
    // 注册用户
    int insertUser(User user);

    // 根据用户名查询用户
    User selectUserByUsername(String username);

    // 根据ID查询用户
    User selectUserById(Integer id);

    // 更新用户信息
    int updateUser(User user);
    
    // 查询所有用户
    List<User> selectAllUsers();
    
    // 删除用户
    int deleteUser(Integer id);
}