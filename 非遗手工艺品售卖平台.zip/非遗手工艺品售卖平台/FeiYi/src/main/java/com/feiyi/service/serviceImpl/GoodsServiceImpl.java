package com.feiyi.service.serviceImpl;

import com.feiyi.mapper.GoodsMapper;
import com.feiyi.pojo.Goods;
import com.feiyi.service.GoodsService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    private GoodsMapper goodsMapper;

    @Override
    public PageInfo<Goods> getGoodsByPage(Integer pageNum, Integer pageSize, Integer categoryId, String keyword) {
        try {
            // 开启分页
            PageHelper.startPage(pageNum, pageSize);
            // 查询商品（注意：这里不再传递pageNum和pageSize参数）
            List<Goods> goodsList = goodsMapper.selectGoodsByPage(categoryId, keyword);
            // 封装分页信息
            return new PageInfo<>(goodsList);
        } catch (Exception e) {
            e.printStackTrace();
            // 出现异常时返回空的分页信息
            return new PageInfo<>(new ArrayList<>());
        }
    }

    @Override
    public Goods getGoodsById(Integer id) {
        try {
            return goodsMapper.selectGoodsById(id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean addGoods(Goods goods) {
        try {
            System.out.println("正在尝试添加商品: " + goods);
            int result = goodsMapper.insertGoods(goods);
            System.out.println("商品添加操作影响行数: " + result);
            return result > 0;
        } catch (Exception e) {
            System.err.println("添加商品时发生异常: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateGoods(Goods goods) {
        try {
            int result = goodsMapper.updateGoods(goods);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteGoods(Integer id) {
        try {
            int result = goodsMapper.deleteGoods(id);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateStock(Integer id, Integer stock) {
        try {
            int result = goodsMapper.updateStock(id, stock);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}