package com.feiyi.controller;

import com.feiyi.pojo.Goods;
import com.feiyi.pojo.User;
import com.feiyi.service.GoodsService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;

@Controller
public class GoodsController {

    @Autowired
    private GoodsService goodsService;

    // 首页，不查询商品（提高性能）
    @GetMapping({"/", "/index"})
    public String index() {
        // 不执行任何数据库查询操作，直接返回首页
        return "index";
    }

    // 商品列表页（保留原有的分页查询功能）
    @GetMapping("/goods/list")
    public String goodsList(@RequestParam(defaultValue = "1") Integer pageNum,
                        @RequestParam(defaultValue = "8") Integer pageSize,
                        @RequestParam(required = false) Integer categoryId,
                        @RequestParam(required = false) String keyword,
                        Model model) {
        try {
            PageInfo<Goods> pageInfo = goodsService.getGoodsByPage(pageNum, pageSize, categoryId, keyword);
            model.addAttribute("pageInfo", pageInfo);
            model.addAttribute("categoryId", categoryId);
            model.addAttribute("keyword", keyword);
        } catch (Exception e) {
            e.printStackTrace();
            // 出现异常时提供空的分页信息
            model.addAttribute("pageInfo", new PageInfo<Goods>(new ArrayList<>()));
            model.addAttribute("categoryId", categoryId);
            model.addAttribute("keyword", keyword);
        }
        return "goods_list"; // 使用专门的商品列表页面
    }

    // 商品详情页
    @GetMapping("/goods/detail")
    public String goodsDetail(@RequestParam(required = false) Integer id, Model model) {
        if (id == null) {
            // 如果id为空，返回错误页面或重定向到商品列表
            return "redirect:/goods/list";
        }
        Goods goods = goodsService.getGoodsById(id);
        model.addAttribute("goods", goods);
        return "goods_detail";
    }

    // 跳转到下单页
    @GetMapping("/order/create")
    public String toOrderCreate(@RequestParam Integer goodsId, @RequestParam(defaultValue = "1") Integer count,
                                HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        Goods goods = goodsService.getGoodsById(goodsId);
        model.addAttribute("goods", goods);
        model.addAttribute("count", count);
        return "order_create";
    }

    // 商品分类页
    @GetMapping("/goods/category")
    public String goodsCategory() {
        return "goods_category";
    }

    // 检查用户是否已登录
    private boolean checkUserLogin(HttpSession session) {
        User user = (User) session.getAttribute("user");
        return user != null;
    }
}