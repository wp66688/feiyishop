package com.feiyi.controller;

import com.feiyi.pojo.*;
import com.feiyi.service.GoodsService;
import com.feiyi.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private GoodsService goodsService;

    // 创建订单
    @PostMapping("/create")
    public String createOrder(@RequestParam Integer goodsId,
                              @RequestParam Integer count,
                              HttpSession session,
                              Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login.jsp";
        }

        try {
            // 获取商品信息
            Goods goods = goodsService.getGoodsById(goodsId);
            if (goods == null) {
                model.addAttribute("error", "商品不存在");
                return "order_create";
            }

            if (goods.getStock() < count) {
                model.addAttribute("error", "商品库存不足");
                model.addAttribute("goods", goods);
                model.addAttribute("count", count);
                return "order_create";
            }

            // 创建订单
            Order order = new Order();
            String orderId = UUID.randomUUID().toString().replace("-", "");
            order.setId(orderId);
            order.setUserId(user.getId());
            order.setTotalPrice(goods.getPrice().multiply(new BigDecimal(count)));
            order.setStatus(0); // 待付款状态
            order.setCreateTime(new Date());

            // 创建订单项
            List<OrderItem> orderItems = new ArrayList<>();
            OrderItem item = new OrderItem();
            item.setOrderId(orderId);
            item.setGoodsId(goodsId);
            item.setCount(count);
            item.setPrice(goods.getPrice());
            orderItems.add(item);

            // 保存订单
            boolean result = orderService.createOrder(order, orderItems);
            
            if (result) {
                return "redirect:/order/detail?id=" + orderId;
            } else {
                model.addAttribute("error", "订单创建失败");
                return "order_create";
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "订单创建失败：" + e.getMessage());
            return "order_create";
        }
    }

    // 订单详情
    @GetMapping("/detail")
    public String orderDetail(@RequestParam String id, HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login.jsp";
        }

        Order order = orderService.getOrderById(id);
        if (order == null) {
            model.addAttribute("error", "订单不存在");
            return "error";
        }
        
        // 检查是否是当前用户的订单
        if (!order.getUserId().equals(user.getId())) {
            model.addAttribute("error", "无权访问该订单");
            return "error";
        }

        model.addAttribute("order", order);
        return "order_detail";
    }

    // 用户订单列表
    @GetMapping("/list")
    public String orderList(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login.jsp";
        }

        List<Order> orders = orderService.getOrdersByUserId(user.getId());
        model.addAttribute("orderList", orders);
        return "order_list";
    }

    // 支付订单页面
    @GetMapping("/pay/{id}")
    public String payOrderPage(@PathVariable String id, HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login.jsp";
        }

        Order order = orderService.getOrderById(id);
        if (order == null || !order.getUserId().equals(user.getId())) {
            model.addAttribute("error", "订单不存在或无权访问");
            return "error";
        }

        if (order.getStatus() != 0) {
            model.addAttribute("error", "订单状态不允许支付");
            return "error";
        }

        model.addAttribute("order", order);
        return "order_pay";
    }

    // 处理支付订单
    @PostMapping("/pay")
    public String processPayOrder(@RequestParam String id, 
                                 @RequestParam String paymentMethod,
                                 HttpSession session, 
                                 Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login.jsp";
        }

        Order order = orderService.getOrderById(id);
        if (order == null || !order.getUserId().equals(user.getId())) {
            model.addAttribute("error", "订单不存在或无权访问");
            return "error";
        }

        if (order.getStatus() != 0) {
            model.addAttribute("error", "订单状态不允许支付");
            return "error";
        }

        // 更新订单状态为已支付
        orderService.updateOrderStatus(id, 1); // 1表示已支付
        
        // 重定向到支付成功页面（这里简化为订单详情页）
        return "redirect:/order/detail?id=" + id + "&paymentSuccess=true";
    }

    // 取消订单
    @PostMapping("/cancel")
    public String cancelOrder(@RequestParam String id, HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login.jsp";
        }

        Order order = orderService.getOrderById(id);
        if (order == null || !order.getUserId().equals(user.getId())) {
            model.addAttribute("error", "订单不存在或无权访问");
            return "error";
        }

        // 更新订单状态为已取消
        orderService.updateOrderStatus(id, 3); // 3表示已取消
        return "redirect:/order/detail?id=" + id;
    }
}