package com.feiyi.mapper;

import com.feiyi.pojo.Order;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderMapper {
    // 创建订单
    int insertOrder(Order order);

    // 根据用户ID查询订单
    List<Order> selectOrderByUserId(Integer userId);

    // 根据订单ID查询订单
    Order selectOrderById(String id);

    // 更新订单状态
    int updateOrderStatus(@Param("id") String id, @Param("status") Integer status);

    // 管理员查询所有订单
    List<Order> selectAllOrder();
    
    // 根据商家ID查询订单
    List<Order> selectOrdersByMerchantId(Integer merchantId);
}