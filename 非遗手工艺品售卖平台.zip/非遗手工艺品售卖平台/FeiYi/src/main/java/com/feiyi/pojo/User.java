package com.feiyi.pojo;

import java.util.Date;

public class User {
    private Integer id;
    private String username;
    private String password; // 存储加密后的密码
    private String phone;
    private String address;
    private Integer role; // 0-普通用户，1-管理员，2-商家
    private Date createTime;

    // 无参构造函数
    public User() {
        this.createTime = new Date(); // 初始化创建时间
    }

    // 有参构造（按需）
    public User(String username, String password) {
        this.username = username;
        // 注意：实际应用中应该在Service层进行加密处理
        this.password = password;
        this.createTime = new Date(); // 初始化创建时间
    }

    // getter和setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    // toString
    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", phone='" + phone + '\'' +
                ", address='" + address + '\'' +
                ", role=" + role +
                ", createTime=" + createTime +
                '}';
    }
}