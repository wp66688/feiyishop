package com.feiyi.controller;

import com.feiyi.pojo.Goods;
import com.feiyi.pojo.Order;
import com.feiyi.pojo.User;
import com.feiyi.service.GoodsService;
import com.feiyi.service.OrderService;
import com.feiyi.service.UserService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private GoodsService goodsService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private UserService userService;

    // 权限验证
    private boolean checkAdmin(HttpSession session) {
        User user = (User) session.getAttribute("user");
        return user != null && user.getRole() == 1;
    }

    // 管理员主页
    @GetMapping({"", "/"})
    public String adminHome(HttpSession session, Model model) {
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        
        try {
            System.out.println("开始获取统计数据...");
            
            // 获取用户总数
            List<User> allUsers = userService.getAllUsers();
            long userCount = allUsers != null ? allUsers.size() : 0;
            System.out.println("用户总数: " + userCount);
            
            // 获取商品总数
            PageInfo<Goods> goodsPageInfo = goodsService.getGoodsByPage(1, 1, null, null);
            long goodsCount = goodsPageInfo != null ? goodsPageInfo.getTotal() : 0;
            System.out.println("商品总数: " + goodsCount);
            
            // 获取订单总数
            List<Order> allOrders = orderService.getAllOrders();
            long orderCount = allOrders != null ? allOrders.size() : 0;
            System.out.println("订单总数: " + orderCount);
            
            // 计算总销售额
            double totalSales = 0.0;
            if (allOrders != null) {
                for (Order order : allOrders) {
                    if (order.getStatus() != null && order.getStatus() >= 1 && order.getTotalPrice() != null) {
                        totalSales += order.getTotalPrice().doubleValue();
                    }
                }
            }
            System.out.println("总销售额: " + totalSales);
            
            // 获取最近7天的订单统计（简化版）
            int[] dailyOrderStats = {15, 18, 12, 20, 25, 22, 19};
            String[] days = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"};
            
            model.addAttribute("userCount", userCount);
            model.addAttribute("goodsCount", goodsCount);
            model.addAttribute("orderCount", orderCount);
            model.addAttribute("totalSales", totalSales);
            model.addAttribute("dailyOrderStats", dailyOrderStats);
            model.addAttribute("days", days);
            
            System.out.println("统计数据获取完成");
        } catch (Exception e) {
            System.err.println("获取统计数据时发生错误: " + e.getMessage());
            e.printStackTrace();
            // 出现异常时使用默认值
            model.addAttribute("userCount", 0);
            model.addAttribute("goodsCount", 0);
            model.addAttribute("orderCount", 0);
            model.addAttribute("totalSales", 0.0);
            int[] defaultStats = {15, 18, 12, 20, 25, 22, 19};
            String[] defaultDays = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"};
            model.addAttribute("dailyOrderStats", defaultStats);
            model.addAttribute("days", defaultDays);
        }
        
        return "admin/admin";
    }

    // 商品管理页
    @GetMapping("/goods_manage")
    public String goodsManage(@RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum,
                              @RequestParam(value = "pageSize", defaultValue = "8") Integer pageSize,
                              @RequestParam(value = "keyword", required = false) String keyword,
                              HttpSession session, Model model) {
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        PageInfo<Goods> pageInfo = goodsService.getGoodsByPage(pageNum, pageSize, null, keyword);
        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("keyword", keyword);
        return "admin/goods_manage";
    }

    // 跳转到添加商品页
    @GetMapping("/goods/add")
    public String toAddGoods(HttpSession session) {
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        return "merchant/goods_add";
    }

    // 添加商品
    @PostMapping("/goods/add")
    public String addGoods(Goods goods, HttpSession session) {
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        User admin = (User) session.getAttribute("user");
        goods.setSellerId(admin.getId()); // 设置卖家ID为当前管理员ID
        goods.setCreateTime(new Date()); // 设置创建时间
        goodsService.addGoods(goods);
        return "redirect:/admin/goods_manage";
    }

    // 跳转到编辑商品页
    @GetMapping("/goods/edit")
    public String toEditGoods(@RequestParam Integer id, HttpSession session, Model model) {
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        Goods goods = goodsService.getGoodsById(id);
        model.addAttribute("goods", goods);
        return "merchant/goods_edit";
    }

    // 编辑商品
    @PostMapping("/goods/edit")
    public String editGoods(Goods goods, HttpSession session) {
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        goodsService.updateGoods(goods);
        return "redirect:/admin/goods_manage";
    }

    // 删除商品
    @GetMapping("/goods/delete")
    public String deleteGoods(@RequestParam Integer id, HttpSession session) {
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        goodsService.deleteGoods(id);
        return "redirect:/admin/goods_manage";
    }

    // 订单管理页
    @GetMapping("/order_manage")
    public String orderManage(HttpSession session, Model model) {
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        List<Order> orderList = orderService.getAllOrders();
        model.addAttribute("orderList", orderList);
        return "admin/order_manage";
    }

    // 更新订单状态
    @GetMapping("/order/update_status")
    public String updateOrderStatus(@RequestParam String id, @RequestParam Integer status, HttpSession session) {
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        orderService.updateOrderStatus(id, status);
        return "redirect:/admin/order_manage";
    }

    // 用户管理页
    @GetMapping("/user_manage")
    public String userManage(HttpSession session, Model model) {
        // 检查是否为管理员
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        
        // 查询所有用户
        List<User> userList = userService.getAllUsers();
        model.addAttribute("userList", userList);
        return "admin/user_manage";
    }
    
    // 更新用户信息（包括角色）
    @RequestMapping(value = "/user/update", method = {RequestMethod.POST, RequestMethod.GET})
    public String updateUser(@RequestParam Integer userId,
                           @RequestParam(required = false) String phone,
                           @RequestParam(required = false) String address,
                           @RequestParam Integer role,
                           HttpSession session,
                           Model model) {
        // 检查是否为管理员
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        
        try {
            // 获取要更新的用户
            User user = userService.getUserById(userId);
            if (user != null) {
                // 只更新角色，不更新其他字段
                user.setRole(role);
                // 显式设置密码为null，确保不更新密码字段
                user.setPassword(null);
                boolean success = userService.updateUser(user);
                if (success) {
                    model.addAttribute("message", "用户信息更新成功");
                } else {
                    model.addAttribute("error", "用户信息更新失败");
                }
            } else {
                model.addAttribute("error", "用户不存在");
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "更新用户信息时发生异常：" + e.getMessage());
        }
        
        // 重新加载用户列表
        List<User> userList = userService.getAllUsers();
        model.addAttribute("userList", userList);
        return "admin/user_manage";
    }
    
    // 删除用户
    @GetMapping("/user/delete")
    public String deleteUser(@RequestParam Integer userId, HttpSession session, Model model) {
        // 检查是否为管理员
        if (!checkAdmin(session)) {
            return "redirect:/login";
        }
        
        try {
            // 不能删除自己
            User currentUser = (User) session.getAttribute("user");
            if (currentUser.getId().equals(userId)) {
                model.addAttribute("error", "不能删除当前登录的管理员账户");
            } else {
                // 执行删除用户的业务逻辑
                boolean success = userService.deleteUser(userId);
                if (success) {
                    model.addAttribute("message", "用户删除成功");
                } else {
                    model.addAttribute("error", "用户删除失败");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "删除用户时发生异常：" + e.getMessage());
        }
        
        // 重新加载用户列表
        List<User> userList = userService.getAllUsers();
        model.addAttribute("userList", userList);
        return "admin/user_manage";
    }
}