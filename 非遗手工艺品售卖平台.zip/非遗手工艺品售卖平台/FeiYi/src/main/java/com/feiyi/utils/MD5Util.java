package com.feiyi.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Util {
    // 盐值，增加加密复杂度
    private static final String SALT = "feiyi_shop";

    // MD5加密方法
    public static String md5(String str) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest((str + SALT).getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                int bt = b & 0xff;
                if (bt < 16) {
                    sb.append(0);
                }
                sb.append(Integer.toHexString(bt));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("MD5 algorithm not found", e);
        }
    }

    // 测试
    public static void main(String[] args) {
        System.out.println(md5("123456")); // 输出加密后的密码
    }
}
