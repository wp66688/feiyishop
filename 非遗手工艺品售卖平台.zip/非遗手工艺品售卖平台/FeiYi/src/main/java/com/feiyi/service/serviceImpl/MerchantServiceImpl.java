package com.feiyi.service.serviceImpl;

import com.feiyi.mapper.MerchantMapper;
import com.feiyi.pojo.Merchant;
import com.feiyi.pojo.Goods;
import com.feiyi.service.MerchantService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class MerchantServiceImpl implements MerchantService {

    @Autowired
    private MerchantMapper merchantMapper;

    @Override
    public Merchant getMerchantById(Integer id) {
        try {
            return (Merchant) merchantMapper.selectMerchantById(id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Merchant getMerchantByUsername(String username) {
        try {
            return (Merchant) merchantMapper.selectMerchantByUsername(username);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public PageInfo<Merchant> getAllMerchantsByPage(Integer pageNum, Integer pageSize) {
        try {
            PageHelper.startPage(pageNum, pageSize);
            List<Merchant> merchants = (List<Merchant>)(List<?>) merchantMapper.selectAllMerchants();
            return new PageInfo(merchants);
        } catch (Exception e) {
            e.printStackTrace();
            return new PageInfo<>(new ArrayList<>());
        }
    }

    @Override
    public boolean addMerchant(Merchant merchant) {
        try {
            int result = merchantMapper.insertMerchant(merchant);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateMerchant(Merchant merchant) {
        try {
            int result = merchantMapper.updateMerchant(merchant);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteMerchant(Integer id) {
        try {
            int result = merchantMapper.deleteMerchant(id);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean approveMerchant(Integer id) {
        try {
            Merchant merchant = (Merchant) merchantMapper.selectMerchantById(id);
            if (merchant != null) {
                merchant.setStatus(1); // 设置为正常状态
                int result = merchantMapper.updateMerchant(merchant);
                return result > 0;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean freezeMerchant(Integer id) {
        try {
            Merchant merchant = (Merchant) merchantMapper.selectMerchantById(id);
            if (merchant != null) {
                merchant.setStatus(2); // 设置为冻结状态
                int result = merchantMapper.updateMerchant(merchant);
                return result > 0;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public PageInfo<Goods> getGoodsByMerchantId(Integer merchantId, Integer pageNum, Integer pageSize) {
        try {
            PageHelper.startPage(pageNum, pageSize);
            List<Goods> goodsList = merchantMapper.selectGoodsByMerchantId(merchantId);
            return new PageInfo<>(goodsList);
        } catch (Exception e) {
            e.printStackTrace();
            return new PageInfo<>(new ArrayList<>());
        }
    }

    @Override
    public int countGoodsByMerchantId(Integer merchantId) {
        try {
            return merchantMapper.countGoodsByMerchantId(merchantId);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
}
