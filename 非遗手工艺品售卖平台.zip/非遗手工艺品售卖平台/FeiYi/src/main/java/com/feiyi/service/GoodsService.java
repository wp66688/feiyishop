package com.feiyi.service;

import com.feiyi.pojo.Goods;
import com.github.pagehelper.PageInfo;
import java.util.List;

public interface GoodsService {
    // 分页查询商品
    PageInfo<Goods> getGoodsByPage(Integer pageNum, Integer pageSize, Integer categoryId, String keyword);

    // 根据ID查询商品
    Goods getGoodsById(Integer id);

    // 添加商品
    boolean addGoods(Goods goods);

    // 更新商品
    boolean updateGoods(Goods goods);

    // 删除商品
    boolean deleteGoods(Integer id);

    // 更新库存
    boolean updateStock(Integer id, Integer stock);

}