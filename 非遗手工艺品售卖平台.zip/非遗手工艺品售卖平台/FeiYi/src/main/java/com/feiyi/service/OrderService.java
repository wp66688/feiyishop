package com.feiyi.service;

import com.feiyi.pojo.Order;
import com.feiyi.pojo.OrderItem;
import java.util.List;

public interface OrderService {
    // 创建订单
    boolean createOrder(Order order, List<OrderItem> orderItems);

    // 根据用户ID查询订单
    List<Order> getOrdersByUserId(Integer userId);

    // 根据订单ID查询订单
    Order getOrderById(String id);

    // 更新订单状态
    boolean updateOrderStatus(String id, Integer status);

    // 管理员查询所有订单
    List<Order> getAllOrders();
    
    // 根据商家ID查询订单
    List<Order> getOrdersByMerchantId(Integer merchantId);
}