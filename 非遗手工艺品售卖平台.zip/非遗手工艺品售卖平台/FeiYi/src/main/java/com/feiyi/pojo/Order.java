package com.feiyi.pojo;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class Order {
    private String id;
    private Integer userId; // 对应数据库中的user_id字段
    private BigDecimal totalPrice; // 对应数据库中的total_price字段
    private Integer status;
    private Date createTime; // 对应数据库中的create_time字段

    // 关联用户和订单详情
    private User user;
    private List<OrderItem> orderItems;


    // getter和setter
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public BigDecimal getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

    // toString
    @Override
    public String toString() {
        return "Order{" +
                "id='" + id + '\'' +
                ", userId=" + userId +
                ", totalPrice=" + totalPrice +
                ", status=" + status +
                ", createTime=" + createTime +
                ", user=" + user +
                ", orderItems=" + orderItems +
                '}';
    }
}