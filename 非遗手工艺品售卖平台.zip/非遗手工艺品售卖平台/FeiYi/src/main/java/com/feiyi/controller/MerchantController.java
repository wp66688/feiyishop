package com.feiyi.controller;

import com.feiyi.pojo.Goods;
import com.feiyi.pojo.Order;
import com.feiyi.pojo.User;
import com.feiyi.service.GoodsService;
import com.feiyi.service.UserService;
import com.feiyi.service.OrderService;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/merchant")
public class MerchantController {

    @Autowired
    private GoodsService goodsService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private OrderService orderService;

    // 检查用户是否已登录且为商家
    private boolean checkMerchantLogin(HttpSession session) {
        User user = (User) session.getAttribute("user");
        // 商家角色为2，参考UserController中的登录逻辑
        return user != null && user.getRole() != null && user.getRole() == 2;
    }

    // 商家管理中心首页
    @GetMapping("/dashboard")
    public String merchantDashboard(HttpSession session, Model model) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }
        User merchant = (User) session.getAttribute("user");
        
        try {
            // 获取商家的商品总数
            PageInfo<Goods> goodsPageInfo = goodsService.getGoodsByPage(1, 1, null, null);
            long goodsCount = goodsPageInfo != null ? goodsPageInfo.getTotal() : 0;
            
            // 获取商家的订单列表
            List<Order> merchantOrders = orderService.getOrdersByMerchantId(merchant.getId());
            long orderCount = merchantOrders != null ? merchantOrders.size() : 0;
            
            // 计算待处理订单数（已付款但未发货的订单）
            long pendingOrderCount = 0;
            if (merchantOrders != null) {
                for (Order order : merchantOrders) {
                    if (order.getStatus() != null && order.getStatus() == 1) { // 已付款状态
                        pendingOrderCount++;
                    }
                }
            }
            
            // 计算本月销售额
            double monthlySales = 0.0;
            if (merchantOrders != null) {
                Date now = new Date();
                for (Order order : merchantOrders) {
                    if (order.getStatus() != null && order.getStatus() >= 1 && 
                        order.getCreateTime() != null && order.getTotalPrice() != null) {
                        // 检查是否是本月的订单
                        Date orderDate = order.getCreateTime();
                        if (isSameMonth(orderDate, now)) {
                            monthlySales += order.getTotalPrice().doubleValue();
                        }
                    }
                }
            }
            
            model.addAttribute("merchant", merchant);
            model.addAttribute("goodsCount", goodsCount);
            model.addAttribute("orderCount", orderCount);
            model.addAttribute("pendingOrderCount", pendingOrderCount);
            model.addAttribute("monthlySales", monthlySales);
        } catch (Exception e) {
            e.printStackTrace();
            // 出现异常时使用默认值
            model.addAttribute("merchant", merchant);
            model.addAttribute("goodsCount", 0);
            model.addAttribute("orderCount", 0);
            model.addAttribute("pendingOrderCount", 0);
            model.addAttribute("monthlySales", 0.0);
        }
        
        return "merchant/merchant";
    }
    
    // 辅助方法：判断两个日期是否在同一月份
    private boolean isSameMonth(Date date1, Date date2) {
        java.util.Calendar cal1 = java.util.Calendar.getInstance();
        java.util.Calendar cal2 = java.util.Calendar.getInstance();
        cal1.setTime(date1);
        cal2.setTime(date2);
        return cal1.get(java.util.Calendar.YEAR) == cal2.get(java.util.Calendar.YEAR) &&
               cal1.get(java.util.Calendar.MONTH) == cal2.get(java.util.Calendar.MONTH);
    }

    // 商家商品管理页面
    @GetMapping("/goods/manage")
    public String manageGoods(@RequestParam(defaultValue = "1") Integer pageNum,
                              @RequestParam(defaultValue = "10") Integer pageSize,
                              @RequestParam(required = false) String keyword,
                              HttpSession session, Model model) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }

        User merchant = (User) session.getAttribute("user");
        try {
            // 获取当前商家的商品列表
            PageInfo<Goods> pageInfo = goodsService.getGoodsByPage(pageNum, pageSize, null, keyword);
            
            model.addAttribute("pageInfo", pageInfo);
            model.addAttribute("keyword", keyword);
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorMessage", "获取商品列表失败");
        }
        return "merchant/goods_manage"; // 使用现有的商品管理页面
    }

    // 跳转到添加商品页面
    @GetMapping("/goods/add")
    public String toAddGoods(HttpSession session, Model model) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }
        model.addAttribute("goods", new Goods());
        return "merchant/goods_add";
    }

    // 添加商品
    @PostMapping("/goods/add")
    public String addGoods(Goods goods, HttpSession session, Model model) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }

        User merchant = (User) session.getAttribute("user");
        goods.setSellerId(merchant.getId()); // 设置卖家ID为当前商家ID
        goods.setCreateTime(new Date()); // 设置创建时间

        // 数据验证
        StringBuilder errorMsg = new StringBuilder();
        if (goods.getName() == null || goods.getName().trim().isEmpty()) {
            errorMsg.append("商品名称不能为空；");
        }

        if (goods.getPrice() == null) {
            errorMsg.append("商品价格不能为空；");
        } else if (goods.getPrice().compareTo(BigDecimal.ZERO) < 0) {
            errorMsg.append("商品价格不能为负数；");
        }

        if (goods.getStock() == null) {
            goods.setStock(0);
        } else if (goods.getStock() < 0) {
            errorMsg.append("商品库存不能为负数；");
        }

        // 验证分类ID
        if (goods.getCategoryId() != null) {
            // 如果提供了分类ID，必须是1-6之间的有效值
            if (goods.getCategoryId() < 1 || goods.getCategoryId() > 6) {
                errorMsg.append("商品分类ID无效，请选择有效的分类；");
            }
        }
        // 如果category_id为null，允许商品暂时没有分类

        // 如果有验证错误，返回添加页面并显示错误信息
        if (errorMsg.length() > 0) {
            model.addAttribute("errorMessage", errorMsg.toString());
            model.addAttribute("goods", goods);
            return "merchant/goods_add";
        }

        try {
            boolean success = goodsService.addGoods(goods);
            if (success) {
                model.addAttribute("successMessage", "商品添加成功");
                return "redirect:/merchant/goods/manage";
            } else {
                model.addAttribute("errorMessage", "商品添加失败，请检查输入信息是否正确");
                model.addAttribute("goods", goods);
                return "merchant/goods_add";
            }
        } catch (Exception e) {
            model.addAttribute("errorMessage", "商品添加过程中发生错误：" + e.getMessage());
            model.addAttribute("goods", goods);
            return "merchant/goods_add";
        }
    }

    // 跳转到编辑商品页面
    @GetMapping("/goods/edit")
    public String toEditGoods(@RequestParam Integer id, HttpSession session, Model model) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }

        Goods goods = goodsService.getGoodsById(id);
        if (goods == null) {
            return "redirect:/merchant/goods/manage";
        }

        // 检查商品是否属于当前商家
        User merchant = (User) session.getAttribute("user");
        if (!goods.getSellerId().equals(merchant.getId())) {
            return "redirect:/merchant/goods/manage";
        }

        model.addAttribute("goods", goods);
        return "merchant/goods_edit";
    }

    // 编辑商品
    @PostMapping("/goods/edit")
    public String editGoods(Goods goods, HttpSession session) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }

        // 获取原始商品信息以检查权限
        Goods originalGoods = goodsService.getGoodsById(goods.getId());
        if (originalGoods == null) {
            return "redirect:/merchant/goods/manage";
        }

        // 检查商品是否属于当前商家
        User merchant = (User) session.getAttribute("user");
        if (!originalGoods.getSellerId().equals(merchant.getId())) {
            return "redirect:/merchant/goods/manage";
        }

        // 保持卖家ID不变
        goods.setSellerId(originalGoods.getSellerId());
        goods.setCreateTime(originalGoods.getCreateTime());

        goodsService.updateGoods(goods);
        return "redirect:/merchant/goods/manage";
    }

    // 删除商品
    @GetMapping("/goods/delete")
    public String deleteGoods(@RequestParam Integer id, HttpSession session) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }

        // 获取原始商品信息以检查权限
        Goods goods = goodsService.getGoodsById(id);
        if (goods == null) {
            return "redirect:/merchant/goods/manage";
        }

        // 检查商品是否属于当前商家
        User merchant = (User) session.getAttribute("user");
        if (!goods.getSellerId().equals(merchant.getId())) {
            return "redirect:/merchant/goods/manage";
        }

        goodsService.deleteGoods(id);
        return "redirect:/merchant/goods/manage";
    }

    // 添加个人中心功能
    /**
     * 商家个人中心页面
     */
    @GetMapping("/profile")
    public String merchantProfile(HttpSession session, Model model) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }
        
        User merchant = (User) session.getAttribute("user");
        model.addAttribute("merchant", merchant);
        return "merchant/profile";
    }

    // 添加订单管理功能
    
    /**
     * 商家订单管理页面
     */
    @GetMapping("/order/manage")
    public String manageOrders(HttpSession session, Model model) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }
        
        User merchant = (User) session.getAttribute("user");
        try {
            // 获取属于该商家的所有订单
            List<Order> orders = orderService.getOrdersByMerchantId(merchant.getId());
            model.addAttribute("orders", orders);
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorMessage", "获取订单列表失败");
        }
        return "merchant/order_manage";
    }
    
    /**
     * 发货操作
     */
    @PostMapping("/order/deliver")
    public String deliverOrder(@RequestParam String orderId, HttpSession session, Model model) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }
        
        try {
            // 更新订单状态为已发货（状态码2）
            boolean success = orderService.updateOrderStatus(orderId, 2);
            if (success) {
                model.addAttribute("successMessage", "订单发货成功");
            } else {
                model.addAttribute("errorMessage", "订单发货失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("errorMessage", "订单发货过程中发生错误：" + e.getMessage());
        }
        
        return "redirect:/merchant/order/manage";
    }

    /**
     * 更新商家个人信息
     */
    @PostMapping("/profile/update")
    public String updateMerchantProfile(@RequestParam String phone,
                                       @RequestParam String address,
                                       @RequestParam(required = false) String password,
                                       HttpSession session,
                                       Model model) {
        if (!checkMerchantLogin(session)) {
            return "redirect:/login?role=2";
        }

        User merchant = (User) session.getAttribute("user");
        try {
            // 创建一个新的User对象，仅包含需要更新的字段
            User userToUpdate = new User();
            userToUpdate.setId(merchant.getId());
            userToUpdate.setPhone(phone);
            userToUpdate.setAddress(address);
            
            // 只有当提供了新密码时才更新密码
            if (password != null && !password.isEmpty()) {
                userToUpdate.setPassword(password);
            }
            // 如果密码为空，则不设置密码字段，这样UserService就不会更新密码

            // 更新商家信息
            boolean success = userService.updateUser(userToUpdate);
            if (success) {
                // 更新session中的用户信息
                // 重新从数据库获取用户信息以确保数据是最新的
                User updatedMerchant = userService.getUserById(merchant.getId());
                session.setAttribute("user", updatedMerchant);
                model.addAttribute("message", "信息更新成功");
            } else {
                model.addAttribute("error", "信息更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "更新出现异常：" + e.getMessage());
        }
        
        // 从数据库重新获取最新的用户信息显示在页面上
        User latestMerchant = userService.getUserById(merchant.getId());
        model.addAttribute("merchant", latestMerchant);
        return "merchant/profile";
    }
}
