package com.feiyi.service.serviceImpl;

import com.feiyi.mapper.UserMapper;
import com.feiyi.pojo.User;
import com.feiyi.service.UserService;
import com.feiyi.utils.MD5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public boolean register(User user) {
        try {
            // 对密码进行加密处理
            user.setPassword(MD5Util.md5(user.getPassword()));
            int result = userMapper.insertUser(user);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public User login(String username, String password) {
        try {
            // 先根据用户名查询用户
            User user = userMapper.selectUserByUsername(username);
            if (user != null) {
                // 对输入的密码进行加密处理后再比较
                String encryptedPassword = MD5Util.md5(password);
                if (encryptedPassword.equals(user.getPassword())) {
                    return user;
                }
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public User getUserById(Integer id) {
        try {
            return userMapper.selectUserById(id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public User getUserByUsername(String username) {
        try {
            return userMapper.selectUserByUsername(username);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean updateUser(User user) {
        try {
            // 如果密码不为空且不为空字符串，则进行加密处理
            // 否则不更新密码字段
            if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                user.setPassword(MD5Util.md5(user.getPassword()));
            } else {
                // 如果密码为空或空字符串，则设置为null，避免更新密码字段
                user.setPassword(null);
            }
            int result = userMapper.updateUser(user);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<User> getAllUsers() {
        try {
            return userMapper.selectAllUsers();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    @Override
    public boolean deleteUser(Integer id) {
        try {
            int result = userMapper.deleteUser(id);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}