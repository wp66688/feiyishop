package com.feiyi.mapper;

import com.feiyi.pojo.Goods;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface GoodsMapper {
    // 分页查询商品
    List<Goods> selectGoodsByPage(@Param("categoryId") Integer categoryId, @Param("keyword") String keyword);

    // 根据ID查询商品
    Goods selectGoodsById(Integer id);

    // 添加商品
    int insertGoods(Goods goods);

    // 更新商品
    int updateGoods(Goods goods);

    // 删除商品
    int deleteGoods(Integer id);

    // 更新库存
    int updateStock(@Param("id") Integer id, @Param("stock") Integer stock);
    
    // 查询推荐商品
    List<Goods> selectRecommendGoods();
}