package com.feiyi.service.serviceImpl;

import com.feiyi.mapper.GoodsMapper;
import com.feiyi.mapper.OrderItemMapper;
import com.feiyi.mapper.OrderMapper;
import com.feiyi.pojo.Goods;
import com.feiyi.pojo.Order;
import com.feiyi.pojo.OrderItem;
import com.feiyi.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
@Transactional
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderMapper orderMapper;

    @Autowired
    private OrderItemMapper orderItemMapper;

    @Autowired
    private GoodsMapper goodsMapper;

    @Override
    public boolean createOrder(Order order, List<OrderItem> orderItems) {
        try {
            // 设置创建时间
            order.setCreateTime(new Date());
            
            // 插入订单主表
            int orderResult = orderMapper.insertOrder(order);
            
            if (orderResult <= 0) {
                throw new RuntimeException("订单创建失败");
            }
            
            // 批量插入订单详情
            if (orderItems != null && !orderItems.isEmpty()) {
                // 扣减库存并插入订单项
                for (OrderItem item : orderItems) {
                    // 查询商品信息
                    Goods goods = goodsMapper.selectGoodsById(item.getGoodsId());
                    if (goods == null) {
                        throw new RuntimeException("商品不存在");
                    }
                    
                    // 检查库存
                    if (goods.getStock() < item.getCount()) {
                        throw new RuntimeException("商品库存不足");
                    }
                    
                    // 扣减库存
                    int newStock = goods.getStock() - item.getCount();
                    goodsMapper.updateStock(goods.getId(), newStock);
                }
                
                // 批量插入订单项
                int itemResult = orderItemMapper.batchInsertOrderItem(orderItems);
                if (itemResult <= 0) {
                    throw new RuntimeException("订单详情创建失败");
                }
            }
            
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("订单创建失败：" + e.getMessage());
        }
    }

    @Override
    public List<Order> getOrdersByUserId(Integer userId) {
        try {
            List<Order> orders = orderMapper.selectOrderByUserId(userId);
            // 为每个订单加载订单项和商品信息
            if (orders != null) {
                for (Order order : orders) {
                    List<OrderItem> orderItems = orderItemMapper.selectOrderItemByOrderId(order.getId());
                    if (orderItems != null) {
                        for (OrderItem item : orderItems) {
                            Goods goods = goodsMapper.selectGoodsById(item.getGoodsId());
                            item.setGoods(goods);
                        }
                    }
                    order.setOrderItems(orderItems);
                }
            }
            return orders;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Order getOrderById(String id) {
        try {
            Order order = orderMapper.selectOrderById(id);
            if (order != null) {
                // 加载订单项
                List<OrderItem> orderItems = orderItemMapper.selectOrderItemByOrderId(id);
                // 为每个订单项加载商品信息
                if (orderItems != null) {
                    for (OrderItem item : orderItems) {
                        Goods goods = goodsMapper.selectGoodsById(item.getGoodsId());
                        item.setGoods(goods);
                    }
                }
                order.setOrderItems(orderItems);
            }
            return order;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean updateOrderStatus(String id, Integer status) {
        try {
            int result = orderMapper.updateOrderStatus(id, status);
            return result > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<Order> getAllOrders() {
        try {
            List<Order> orders = orderMapper.selectAllOrder();
            // 为每个订单加载订单项和商品信息
            if (orders != null) {
                for (Order order : orders) {
                    List<OrderItem> orderItems = orderItemMapper.selectOrderItemByOrderId(order.getId());
                    if (orderItems != null) {
                        for (OrderItem item : orderItems) {
                            Goods goods = goodsMapper.selectGoodsById(item.getGoodsId());
                            item.setGoods(goods);
                        }
                    }
                    order.setOrderItems(orderItems);
                }
            }
            return orders;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    @Override
    public List<Order> getOrdersByMerchantId(Integer merchantId) {
        try {
            List<Order> orders = orderMapper.selectOrdersByMerchantId(merchantId);
            // 为每个订单加载订单项和商品信息
            if (orders != null) {
                for (Order order : orders) {
                    List<OrderItem> orderItems = orderItemMapper.selectOrderItemByOrderId(order.getId());
                    if (orderItems != null) {
                        for (OrderItem item : orderItems) {
                            Goods goods = goodsMapper.selectGoodsById(item.getGoodsId());
                            item.setGoods(goods);
                        }
                    }
                    order.setOrderItems(orderItems);
                }
            }
            return orders;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}