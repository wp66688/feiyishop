package com.feiyi.controller;

import com.feiyi.pojo.User;
import com.feiyi.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    // 跳转到登录页面
    @GetMapping("/login")
    public String toLogin(@RequestParam(required = false) Integer role, Model model) {
        if (role != null) {
            model.addAttribute("role", role);
        }
        return "login";
    }

    // 处理登录请求
    @PostMapping("/login")
    public String login(@RequestParam String username,
                        @RequestParam String password,
                        @RequestParam(required = false) Integer role,
                        HttpSession session,
                        Model model) {
        try {
            User user = userService.login(username, password);
            if (user != null) {
                // 如果指定了角色，检查用户角色是否匹配
                if (role != null && !user.getRole().equals(role)) {
                    model.addAttribute("error", "角色不匹配，请重新选择正确的登录入口");
                    return "login";
                }
                // 登录成功，将用户信息存入session
                session.setAttribute("user", user);
                // 根据用户角色跳转到不同页面
                switch (user.getRole()) {
                    case 1: // 管理员
                        return "redirect:/admin/";
                    case 2: // 商家
                        // 修改这里：商家登录后直接跳转到商家中心
                        return "redirect:/merchant/dashboard";
                    default: // 普通用户
                        return "redirect:/user/center";
                }
            } else {
                model.addAttribute("error", "用户名或密码错误");
                if (role != null) {
                    model.addAttribute("role", role);
                }
                return "login";
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "登录出现异常：" + e.getMessage());
            return "login";
        }
    }

    // 跳转到注册页面
    @GetMapping("/register")
    public String toRegister() {
        return "register";
    }

    // 用户注册
    @PostMapping("/register")
    public String register(@RequestParam String username,
                           @RequestParam String password,
                           @RequestParam String phone,
                           @RequestParam String address,
                           @RequestParam(defaultValue = "0") Integer role,
                           Model model) {
        try {
            // 检查用户名是否已存在
            User existingUser = userService.getUserByUsername(username);
            if (existingUser != null) {
                model.addAttribute("error", "用户名已存在");
                // 保留用户输入的信息
                User user = new User();
                user.setUsername(username);
                user.setPhone(phone);
                user.setAddress(address);
                model.addAttribute("user", user);
                return "register";
            }

            // 创建新用户
            User user = new User();
            user.setUsername(username);
            user.setPassword(password); // Service层会进行加密处理
            user.setPhone(phone);
            user.setAddress(address);
            user.setRole(role);

            boolean success = userService.register(user);
            if (success) {
                model.addAttribute("message", "注册成功，请登录");
                return "login";
            } else {
                model.addAttribute("error", "注册失败，请稍后重试");
                // 保留用户输入的信息
                user.setPassword(null); // 清除密码
                model.addAttribute("user", user);
                return "register";
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "注册出现异常：" + e.getMessage());
            // 保留用户输入的信息
            User user = new User();
            user.setUsername(username);
            user.setPhone(phone);
            user.setAddress(address);
            model.addAttribute("user", user);
            return "register";
        }
    }

    // 退出登录
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate(); // 清除session
        return "redirect:/";
    }

    // 跳转到用户中心
    @GetMapping({"/user", "/user/center"})
    public String userCenter(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        model.addAttribute("user", user);
        return "user_center";
    }

    // 更新用户信息
    @PostMapping("/user/update")
    public String updateUser(@RequestParam String phone,
                             @RequestParam String address,
                             @RequestParam(required = false) String password,
                             HttpSession session,
                             Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }

        try {
            user.setPhone(phone);
            user.setAddress(address);
            // 如果密码不为空，则更新密码
            if (password != null && !password.isEmpty()) {
                user.setPassword(password); // Service层会进行加密处理
            }

            boolean success = userService.updateUser(user);
            if (success) {
                // 更新session中的用户信息
                session.setAttribute("user", user);
                model.addAttribute("message", "信息更新成功");
            } else {
                model.addAttribute("error", "信息更新失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "更新出现异常：" + e.getMessage());
        }
        model.addAttribute("user", user);
        return "user_center";
    }
}
