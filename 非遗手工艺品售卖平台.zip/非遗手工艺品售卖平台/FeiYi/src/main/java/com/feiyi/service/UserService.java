package com.feiyi.service;

import com.feiyi.pojo.User;
import java.util.List;

public interface UserService {
    // 用户注册
    boolean register(User user);

    // 用户登录
    User login(String username, String password);

    // 根据ID查询用户
    User getUserById(Integer id);

    // 根据用户名查询用户
    User getUserByUsername(String username);

    // 更新用户信息
    boolean updateUser(User user);

    // 查询所有用户
    List<User> getAllUsers();
    
    // 删除用户
    boolean deleteUser(Integer id);
}