package com.feiyi.pojo;

import java.math.BigDecimal;

public class OrderItem {
    private Integer id;
    private String orderId; // 对应数据库中的order_id字段
    private Integer goodsId; // 对应数据库中的goods_id字段
    private Integer count;
    private BigDecimal price;

    // 关联商品
    private Goods goods;


    // getter和setter
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public Integer getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Integer goodsId) {
        this.goodsId = goodsId;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Goods getGoods() {
        return goods;
    }

    public void setGoods(Goods goods) {
        this.goods = goods;
    }

    // toString
    @Override
    public String toString() {
        return "OrderItem{" +
                "id=" + id +
                ", orderId='" + orderId + '\'' +
                ", goodsId=" + goodsId +
                ", count=" + count +
                ", price=" + price +
                ", goods=" + goods +
                '}';
    }
}