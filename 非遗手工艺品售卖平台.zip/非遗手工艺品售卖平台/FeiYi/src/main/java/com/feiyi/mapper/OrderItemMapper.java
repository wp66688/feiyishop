package com.feiyi.mapper;

import com.feiyi.pojo.OrderItem;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderItemMapper {
    // 批量插入订单详情
    int batchInsertOrderItem(@Param("orderItems") List<OrderItem> orderItems);

    // 根据订单ID查询订单详情
    List<OrderItem> selectOrderItemByOrderId(String orderId);
}