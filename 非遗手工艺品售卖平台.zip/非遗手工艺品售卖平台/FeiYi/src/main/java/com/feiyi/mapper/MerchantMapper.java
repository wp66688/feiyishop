package com.feiyi.mapper;

import com.feiyi.pojo.User;
import com.feiyi.pojo.Goods;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface MerchantMapper {
    
    // 根据ID查询商家信息
    User selectMerchantById(Integer id);
    
    // 根据用户名查询商家
    User selectMerchantByUsername(String username);
    
    // 查询所有商家
    List<User> selectAllMerchants();
    
    // 添加商家
    int insertMerchant(User merchant);
    
    // 更新商家信息
    int updateMerchant(User merchant);
    
    // 删除商家
    int deleteMerchant(Integer id);
    
    // 查询某个商家的所有商品
    List<Goods> selectGoodsByMerchantId(@Param("merchantId") Integer merchantId);
    
    // 统计某个商家的商品数量
    int countGoodsByMerchantId(@Param("merchantId") Integer merchantId);
}
