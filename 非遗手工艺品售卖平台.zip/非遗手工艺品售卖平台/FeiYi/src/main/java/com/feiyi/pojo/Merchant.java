package com.feiyi.pojo;

import java.util.Date;

public class Merchant extends User {
    private Integer merchantId; // 对应数据库中的id字段
    private String shopName; // 对应数据库中的shop_name字段
    private String businessLicense; // 对应数据库中的business_license字段
    private String contactPerson; // 对应数据库中的contact_person字段
    private String contactPhone; // 对应数据库中的contact_phone字段
    private String shopAddress; // 对应数据库中的shop_address字段
    private String shopDescription; // 对应数据库中的shop_description字段
    private Date registerTime; // 对应数据库中的register_time字段
    private Integer status; // 商家状态：0-未审核，1-正常，2-冻结

    // 无参构造函数
    public Merchant() {
        super();
        this.registerTime = new Date();
        this.status = 0; // 默认未审核状态
    }

    // getter和setter方法
    public Integer getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(Integer merchantId) {
        this.merchantId = merchantId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getBusinessLicense() {
        return businessLicense;
    }

    public void setBusinessLicense(String businessLicense) {
        this.businessLicense = businessLicense;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getShopAddress() {
        return shopAddress;
    }

    public void setShopAddress(String shopAddress) {
        this.shopAddress = shopAddress;
    }

    public String getShopDescription() {
        return shopDescription;
    }

    public void setShopDescription(String shopDescription) {
        this.shopDescription = shopDescription;
    }

    public Date getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(Date registerTime) {
        this.registerTime = registerTime;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Merchant{" +
                "merchantId=" + merchantId +
                ", shopName='" + shopName + '\'' +
                ", businessLicense='" + businessLicense + '\'' +
                ", contactPerson='" + contactPerson + '\'' +
                ", contactPhone='" + contactPhone + '\'' +
                ", shopAddress='" + shopAddress + '\'' +
                ", shopDescription='" + shopDescription + '\'' +
                ", registerTime=" + registerTime +
                ", status=" + status +
                '}';
    }
}
